import Welcome from "./Welcome";
import FaceLogin from "./FaceLogin";
import NidUser from "./NidUser";
import NotFound from "./NotFound";

export { Welcome, FaceLogin, NidUser, NotFound };
